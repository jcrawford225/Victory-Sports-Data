insert into team values("USER");




INSERT INTO sports_data  values (2,'MIA Marlins', 45);
INSERT INTO sports_data values (1,"TB Rays", 54);
INSERT INTO sports_data values(1,"Texas Rangers", 47);
INSERT INTO sports_data values(1,"Minnesota Twins", 40);
INSERT INTO sports_data values(2,"Baltimore Orioles", 47);
INSERT INTO sports_data  values (1,"Atlanta Braves", 50);
INSERT INTO sports_data values (3,"Yankees", 43);
INSERT INTO sports_data values(2,"Astros", 42);
INSERT INTO sports_data values(2,"LA Angels", 42);
INSERT INTO sports_data values(4,"Blue Jays", 43);
INSERT INTO sports_data values(5,"Red Sox", 40);
