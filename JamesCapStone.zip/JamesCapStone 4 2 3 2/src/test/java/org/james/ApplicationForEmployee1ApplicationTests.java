package org.james;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationForEmployee1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
